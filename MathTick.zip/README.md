# MathTick – APK project

## Easiest: GitHub (no installs)
1. Create a new GitHub repo and upload everything in this folder (keep the .github folder).
2. Open the Actions tab, run "Build APK".
3. When it finishes, download the "MathTick-apk" artifact and unzip it to get app-debug.apk.

## On your PC (Node 18+, Android Studio/SDK, JDK 17)
npm install
npx cap add android
npx @capacitor/assets generate --android --iconBackgroundColor '#0b1a08' --iconBackgroundColorDark '#0b1a08' --splashBackgroundColor '#0b1a08' --splashBackgroundColorDark '#0b1a08'
npx cap sync android
cd android && ./gradlew assembleDebug
APK: android/app/build/outputs/apk/debug/app-debug.apk

## Web-to-APK tools
Upload www/index.html to your usual website-to-APK builder.

Note: alarms ring only while the app is open; background alarms need a native plugin.
